
export class HerolistService{
    getData():string[]{
        return ["Ironman","SpiderMan","AntMan","Superman","Shaktiman"];
    }
}