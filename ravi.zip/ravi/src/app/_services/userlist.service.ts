import { Injectable} from '@angular/core';
import { Http } from '@angular/http';



@Injectable()

export class listService{


 private _url='http://jsonplaceholder.typicode.com/posts';
    
      constructor(private http:Http) { }
    
       getuserList(){
         return this.http.get(this._url)
    
       } 
}