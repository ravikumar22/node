import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class PostService {

  url='http://jsonplaceholder.typicode.com/posts';

  constructor(private http:Http) { }


   getData(){
     return this.http.get(this.url)
   } 

   makeApost(newpost){
    return this.http.post(this.url,newpost)
   }

   //update post
    updatePost(postId){
      let seen={
        seen : true
      }
      let targetUrl =this.url+'/'+postId
     return this.http.patch(targetUrl,seen);
    }

}
