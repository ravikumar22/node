import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',

})
export class UserprofileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
