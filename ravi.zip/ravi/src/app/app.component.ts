import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';
  projectName = 'Vijaya';
  projectUrl  ='http://www.google.com';
  setColor   = true;
  setActive =true;

   movie = {
     neme : 'James bond',
     liked:true

   }

  heartswitch($event){
    this.movie.liked = !this.movie.liked;
  }
}
