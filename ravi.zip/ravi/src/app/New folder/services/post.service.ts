import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class PostService {

  url = 'http://jsonplaceholder.typicode.com/posts';

  constructor(private http:Http) { }

  getData(){
    return this.http.get(this.url).map(response => response.json());
  } 

  makeAPost(newpost){
    return this.http.post(this.url,newpost).map(response => response.json())
  }

  //updatePost
  updatePost(postId){
    let seen = {
      seen: true
    }

    let targetUrl = this.url+'/'+postId

    return this.http.patch(targetUrl,seen).map(response => response.json());
  } 

  //Delete post

  deletePost(postId){
      return this.http.delete(this.url+'/'+postId).map(response => response.json());
  }

   
}
