import {AbstractControl,FormControl,FormGroup, FormArray,  Validators} from '@angular/forms';
import { Component } from '@angular/core';
import { customValidators} from './custom.validators'


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styles: []
})
export class SignupComponent {

  signup = new FormGroup({
     fullname: new FormControl('vijaya',Validators.required),
     
      credentials: new FormGroup({

        username: new FormControl('',[
          Validators.required,
          customValidators.spaceNotAllowed
        ]),
  
       email: new FormControl('',[
         Validators.required,
         Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?")
      
      ]),
       password: new FormControl('', [
            Validators.required,
            Validators.minLength(5)
          
          ]),

      }),
    skills: new FormArray([])
   
  })

  get fullname(){ return this.signup.get('fullname');}
  get username(){ return this.signup.get('credentials.username')}
  get email(){ return this.signup.get('credentials.email')}
  get password(){ return this.signup.get('credentials.password')}

  addSkill( skl:HTMLInputElement){
    if((skl.value as string).length>0)
    (this.signup.get('skills') as FormArray).push( new FormControl(skl.value))
    skl.value=' ';

  }


}
