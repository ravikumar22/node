import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import {FirstComponent} from './first.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { SignupComponent } from './signup/signup.component';
import { UserpostComponent } from './userpost/userpost.component';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component'
import { RouterModule} from '@angular/router';
import { UserprofileComponent } from './userprofile/userprofile.component';
import {UserlistComponent } from './userlist/userlist.component';
@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    WishlistComponent,
    FeedbackComponent,
    SignupComponent,
    UserpostComponent,
    HomeComponent,
    NavbarComponent,
    UserprofileComponent,
    UserlistComponent,
  
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot([
    { path:'', component:HomeComponent},
    { path:'user/:id', component:UserprofileComponent},
    { path: 'users',component: UserprofileComponent},
    { path:'posts/:id', component:UserpostComponent},
    { path: 'posts',component:UserpostComponent},
    { path: 'signup',component:SignupComponent}



    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
