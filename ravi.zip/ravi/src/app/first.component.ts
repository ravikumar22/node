import { Component} from '@angular/core';

@Component({

    selector: 'va-first',
    template: '<h2>My First Component!!</h2>'
})

export class FirstComponent{
    title ="app Works!!"
}