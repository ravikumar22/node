import { Component, OnInit } from '@angular/core';
import { PostService} from '../_services/post.service';

@Component({
  selector: 'app-userpost',
  templateUrl: './userpost.component.html',
  styles: [],
  providers: [PostService]
})
export class UserpostComponent implements OnInit {
posts:any[];
  constructor( private postService:PostService) { }

  ngOnInit() {
    this.postService.getData().subscribe(
      Response => {
        this.posts = Response.json();
        console.log(this.posts);
      }
    )
  }

  createPost( ptitle:HTMLInputElement,pbody:HTMLTextAreaElement){

    let newpost ={
       title: ptitle.value,
       body: pbody.value
    }
    ptitle.value ='';
    pbody.value ='';


    this.postService.makeApost(newpost)
    .subscribe( Response=>{
      console.log( Response.json())
      this.posts.splice(0,0, newpost);
    })

    
  }

  // updated Post
  editPost(post){
    this.postService.updatePost(post.id)
    .subscribe(Response =>{
       console.log(Response)
    })
  }


}
