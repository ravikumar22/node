import { Component} from '@angular/core';
import {NgForm} from '@angular/forms'

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styles: [`
      input.ng-touched.ng-invalid{
        border:1px solid red;
      }

  `]
})
export class FeedbackComponent {

  feeddeta = {
     firstname :'Vijaya',
     email:'jiya.kumari2@gmail.com',
     feedtxt:'Please give some feedback',
     type:'free',
     platform:'web'

  }

  usertypes =['free','premium']
  platforms =['web','ios','android']

onSubmit(form:NgForm){

  console.log(this.feeddeta);
}

}
