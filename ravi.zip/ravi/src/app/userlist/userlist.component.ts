import { Component, OnInit } from '@angular/core';
import { listService}  from '../_services/userlist.service';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css'],
  providers:[listService]
})
export class UserlistComponent implements OnInit {
 lists:any[];
  constructor ( private userlistService:listService) { }

  ngOnInit() {
    this.userlistService.getuserList().subscribe()
    Response =>{
      this.lists = Response.json();
      console.log(this.lists);
    }
  }

}
