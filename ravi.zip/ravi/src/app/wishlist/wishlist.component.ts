import { Component,Input, EventEmitter, Output  } from '@angular/core';

@Component({
  selector: 'wishlist',
  templateUrl: './wishlist.component.html',
  styles: [`.active{ color:red}`]
})
export class WishlistComponent  {
        
@Input() liked;
color = "red";
@Output() likeToggle = new EventEmitter();
 heroes= ["Sarukh khan","Amir khan", "Amitab bchchan","Abhisek"];
 genre="family";
  likeChange($event){
    $event.stopPropagation();
    this.likeToggle.emit();
    }
  

}
