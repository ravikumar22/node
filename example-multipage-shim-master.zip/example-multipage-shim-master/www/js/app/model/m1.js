define(['./Base'], function (Base) {
    var m1 = new Base('This is the data for Page 1');
    return m1;
});
