define(['./Base'], function (Base) {
    var m2 = new Base('This is the data for Page 2');
    return m2;
});
